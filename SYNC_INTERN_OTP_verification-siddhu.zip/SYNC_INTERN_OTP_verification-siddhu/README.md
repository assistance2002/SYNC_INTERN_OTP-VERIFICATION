# SYNC_INTERN_OTP_verification
Task 2 of week 2 internship of SYNC Internship - Python Intern
when user enters his mail id he gets otp genersted random and if he enters right he will we verified or else not verified. a user has atmost 3 chances to get OTP verification at a time.
user can stop verification process at any no of times of wrong attempts(0 to 2).
Note :-Here we need to create 16 digit code at sender google account and then use it to send OTP.
we need to use our gmail ID and that 16 digit code to send otp.
